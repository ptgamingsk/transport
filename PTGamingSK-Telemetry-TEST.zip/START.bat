@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -File "%~dp0Telemetry.ps1"
pause
