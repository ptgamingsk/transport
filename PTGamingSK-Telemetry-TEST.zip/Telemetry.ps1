$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$key='AIzaSyCTyfLQgg3XCwdr8N_hUeLKrsWsnTmLwXM'
$project='ptgamingsk-transport'
$form=New-Object Windows.Forms.Form
$form.Text='PTGamingSK TRANSPORT - Telemetry TEST'; $form.Size=New-Object Drawing.Size(540,370);$form.BackColor=[Drawing.Color]::FromArgb(24,24,24);$form.ForeColor=[Drawing.Color]::LimeGreen
function Label($text,$y){$l=New-Object Windows.Forms.Label;$l.Text=$text;$l.SetBounds(18,$y,490,24);$form.Controls.Add($l);return $l}
function Input($y){$t=New-Object Windows.Forms.TextBox;$t.SetBounds(18,$y,480,26);$form.Controls.Add($t);return $t}
$null=Label 'Firemny e-mail' 15;$mail=Input 40;$null=Label 'Heslo' 75;$pw=Input 100;$pw.UseSystemPasswordChar=$true
$b=New-Object Windows.Forms.Button;$b.Text='Prihlasit a spustit';$b.SetBounds(18,140,220,35);$form.Controls.Add($b)
$status=Label 'Cakam na prihlasenie.' 190;$status.Height=110
$timer=New-Object Windows.Forms.Timer;$timer.Interval=5000
$script:session=$null;$script:expiry=[datetime]::MinValue
function Post($url,$body){Invoke-RestMethod -Method Post -Uri $url -ContentType 'application/json' -Body ($body|ConvertTo-Json -Depth 10 -Compress) -TimeoutSec 8}
function ReadText($v,$offset){$bytes=New-Object byte[] 64;$null=$v.ReadArray($offset,$bytes,0,64);([Text.Encoding]::UTF8.GetString($bytes).Split([char]0)[0])}
$b.Add_Click({try{$script:session=Post "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=$key" @{email=$mail.Text;password=$pw.Text;returnSecureToken=$true};$pw.Clear();$script:expiry=(Get-Date).AddMinutes(50);$status.Text='Prihlaseny. Cakam na ETS2.';$timer.Start();$b.Enabled=$false}catch{$status.Text='Prihlasenie zlyhalo: '+$_.Exception.Message}})
$timer.Add_Tick({try{
if((Get-Date) -gt $script:expiry){$r=Invoke-RestMethod -Method Post -Uri "https://securetoken.googleapis.com/v1/token?key=$key" -Body @{grant_type='refresh_token';refresh_token=$script:session.refreshToken} -TimeoutSec 8;$script:session.idToken=$r.id_token;$script:session.refreshToken=$r.refresh_token;$script:expiry=(Get-Date).AddMinutes(50)}
$m=$null;$v=$null;try{$m=[IO.MemoryMappedFiles.MemoryMappedFile]::OpenExisting('Local\SCSTelemetry',[IO.MemoryMappedFiles.MemoryMappedFileRights]::Read);$v=$m.CreateViewAccessor(0,0,[IO.MemoryMappedFiles.MemoryMappedFileAccess]::Read);if(!$v.ReadBoolean(0)){throw 'SDK nie je aktivne'};$version=$v.ReadUInt32(40);$game=$v.ReadUInt32(52);$x=$v.ReadDouble(2200);$z=$v.ReadDouble(2216)
}finally{if($v){$v.Dispose()};if($m){$m.Dispose()}}
# Diagnostic only until offsets are validated against a live game.
$status.Text="SDK signal: X=$x Z=$z`r`nDLL version=$version Game=$game`r`nTEST: No data is sent until layout verification."
}catch{$status.Text='Cakam na kompatibilny SDK: '+$_.Exception.Message}})
$form.Add_FormClosed({$timer.Stop();$script:session=$null});[void]$form.ShowDialog()
