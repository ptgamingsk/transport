PTGamingSK TRANSPORT - diagnosticka verzia
1. Vypni ETS2. DLL vloz do bin\win_x64\plugins (ak ju tam este nemas).
2. Spusti ETS2 a nacitaj profil.
3. Spusti START.bat. Ak Windows blokuje skript, neobchadzaj ochranu; kontaktuj spravcu.
4. Prihlas sa vlastnym firemnym uctom a posli snimku diagnostiky bez hesla.
Tato verzia overuje prihlasenie a citanie SDK; este neposiela data na web.
DLL dodal pouzivatel, povod RenCloud: https://github.com/RenCloud/scs-sdk-plugin
